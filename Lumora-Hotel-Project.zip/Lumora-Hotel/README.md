# LUMORA HOTEL

Website reservasi dan simulasi check-in hotel untuk project kelas 11 RPL.

## Teknologi
- HTML
- CSS
- JavaScript
- LocalStorage (penyimpanan data reservasi sementara di browser)

## Cara menjalankan
1. Ekstrak folder `Lumora-Hotel`.
2. Buka folder menggunakan Visual Studio Code.
3. Jalankan `index.html` dengan browser atau gunakan ekstensi Live Server.
4. Buka halaman Booking, isi formulir, lalu simpan kode booking yang muncul.
5. Buka halaman Check-in dan masukkan kode booking serta nama yang sama.

## Halaman
- `index.html` — Home
- `about.html` — About
- `rooms.html` — Daftar kamar
- `booking.html` — Simulasi reservasi
- `checkin.html` — Simulasi check-in
- `contact.html` — Kontak

## Catatan
Project ini hanya frontend. Reservasi tersimpan pada LocalStorage browser yang sama, bukan database server. Nama hotel, alamat, nomor telepon, email, harga, dan foto merupakan data contoh yang dapat diganti.
