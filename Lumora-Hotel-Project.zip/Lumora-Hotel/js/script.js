// Navigasi mobile
const menuButton = document.querySelector(".menu-btn");
const navLinks = document.querySelector(".nav-links");

if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => navLinks.classList.toggle("show"));
}

// Tanggal minimum adalah hari ini
const today = new Date().toISOString().split("T")[0];
document.querySelectorAll('input[type="date"]').forEach(input => {
  input.min = today;
});

// Form booking: hitung harga dan simpan reservasi sementara di browser
const bookingForm = document.querySelector("#bookingForm");
if (bookingForm) {
  const checkIn = document.querySelector("#checkinDate");
  const checkOut = document.querySelector("#checkoutDate");
  const roomType = document.querySelector("#roomType");
  const guests = document.querySelector("#guests");
  const totalPreview = document.querySelector("#totalPreview");

  function calculateTotal() {
    if (!checkIn.value || !checkOut.value || !roomType.value) {
      totalPreview.textContent = "Pilih kamar dan tanggal untuk melihat perkiraan biaya.";
      return 0;
    }
    const start = new Date(checkIn.value);
    const end = new Date(checkOut.value);
    const nights = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    if (nights <= 0) {
      totalPreview.textContent = "Tanggal check-out harus setelah tanggal check-in.";
      return 0;
    }
    const price = Number(roomType.selectedOptions[0].dataset.price);
    const total = nights * price;
    totalPreview.textContent = `${nights} malam × ${formatRupiah(price)} = ${formatRupiah(total)}`;
    return total;
  }

  [checkIn, checkOut, roomType].forEach(el => el.addEventListener("change", calculateTotal));

  bookingForm.addEventListener("submit", event => {
    event.preventDefault();
    const total = calculateTotal();
    if (!bookingForm.reportValidity()) return;
    if (!total) {
      alert("Periksa kembali tanggal dan pilihan kamar.");
      return;
    }

    const booking = {
      code: "LMR" + Date.now().toString().slice(-7),
      name: document.querySelector("#guestName").value.trim(),
      email: document.querySelector("#guestEmail").value.trim(),
      phone: document.querySelector("#guestPhone").value.trim(),
      room: roomType.value,
      checkin: checkIn.value,
      checkout: checkOut.value,
      guests: guests.value,
      total: total,
      status: "Menunggu check-in"
    };

    localStorage.setItem("lumoraBooking", JSON.stringify(booking));
    document.querySelector("#bookingNotice").style.display = "block";
    document.querySelector("#bookingNotice").innerHTML =
      `Reservasi berhasil dibuat untuk simulasi!<br>Kode booking: <strong>${booking.code}</strong><br>Total: <strong>${formatRupiah(total)}</strong><br>Simpan kode ini untuk mengisi halaman check-in.`;
    bookingForm.reset();
    totalPreview.textContent = "Pilih kamar dan tanggal untuk melihat perkiraan biaya.";
  });
}

// Form check-in: cocokkan kode dengan reservasi di browser
const checkinForm = document.querySelector("#checkinForm");
if (checkinForm) {
  checkinForm.addEventListener("submit", event => {
    event.preventDefault();
    if (!checkinForm.reportValidity()) return;

    const savedBooking = JSON.parse(localStorage.getItem("lumoraBooking") || "null");
    const code = document.querySelector("#bookingCode").value.trim().toUpperCase();
    const name = document.querySelector("#checkinName").value.trim();
    const identity = document.querySelector("#identityNumber").value.trim();
    const notice = document.querySelector("#checkinNotice");

    if (!savedBooking || code !== savedBooking.code || name.toLowerCase() !== savedBooking.name.toLowerCase()) {
      notice.style.display = "block";
      notice.textContent = "Data reservasi tidak ditemukan. Periksa kembali kode booking dan nama sesuai reservasi.";
      notice.style.background = "#fff3f0";
      notice.style.color = "#8a3528";
      notice.style.borderColor = "#c96d5d";
      return;
    }

    savedBooking.status = "Check-in selesai (simulasi)";
    savedBooking.identityLastDigits = identity.slice(-4);
    localStorage.setItem("lumoraBooking", JSON.stringify(savedBooking));
    notice.style.display = "block";
    notice.style.background = "#f2f7ef";
    notice.style.color = "#3d5b32";
    notice.style.borderColor = "#71945e";
    notice.innerHTML = `Check-in simulasi berhasil, ${savedBooking.name}!<br>Kamar: <strong>${savedBooking.room}</strong><br>Tanggal menginap: <strong>${savedBooking.checkin}</strong> sampai <strong>${savedBooking.checkout}</strong>.`;
    checkinForm.reset();
  });
}

function formatRupiah(value) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(value);
}
